﻿
namespace ChenChienLin550CAssignment8ComplexNumber
{
    class Program
    {
        public static void Main(string[] args)
        {

        }
    }
}
