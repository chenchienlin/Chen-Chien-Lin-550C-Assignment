﻿using System;

namespace ChenChienLin550CAssignment8Project
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
