# Chen-Chien-Lin-MECH 550C-Assignment 2

This project is for MECH 550C Assignment 2

## Description
One Rectangular class and two instances of the class are created. The size of a rectangular can only be defined once by its constructor.
A getter is defined to get the value of the area of the rectangular.<br/>
<br/>
Two arguments are needed to create a rectangular, length and width, respectively. Both of these two value can only be postive numbers.
If the arguments are zero or negative, the program will throw an exception.<br/>
<br/>
A static method is defined to compare the areas of two rectangular, and will return boolean value.

## Author
Chen_Chien Lin
